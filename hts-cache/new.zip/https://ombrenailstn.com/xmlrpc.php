<!DOCTYPE html>
<html>
  <head>
    <title>405 Not allowed.</title>
  </head>
  <body>
    <h1>Error 405 Not allowed.</h1>
    <p>Not allowed.</p>
    <h3>Guru Meditation:</h3>
    <p>XID: 95422601</p>
    <hr>
    <p>Varnish cache server</p>
  </body>
</html>
